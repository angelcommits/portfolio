### Tarea 02: Implementar sistema de bootstrap

- **Prompt**: `/sc:implement .docs/workbook/002.00 | Creación de Modelos Base (User, Platform, Role).md" --type script --framework rails --persona-backend --with-tests`
- **Persona**: backend
- **Commit**: `feat: add bootstrap system [SC #09]`
